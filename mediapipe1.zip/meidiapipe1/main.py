import cv2
im = cv2.imread('D:/mediapipe/chenjie.png')
cv2.rectangle(im, (350, 50), (560, 375), (0, 0, 255), 2)

cv2.putText(im,'CHENJIE', (325, 415), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 2)
#cv2.putText(img, text, org, fontFace, fontScale, color[, thickness[, lineType[, bottomLeftOrigin]]])
#text：要绘制的文字， org：文字在图像中的左下角坐标
# fontFace：字体， fontScale：字体大小，该值和基础大小相乘得到字体大小
# color：文字颜色， thickness：字体线条宽度
# bottomLeftOrigin：为 true，图像数据原点在左下角；否则，图像数据原点在左上角

cv2.imshow('a frame', im)	# a frame 是显示窗口的的标题名称
cv2.waitKey(0)
cv2.destroyAllWindows()
